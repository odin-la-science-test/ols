import { SimulationParams, SimulationResult, TimePointData, CheckpointAnalysis, AgentRecommendation, BacteriaType, MediumType, PhaseBoundaries } from "../types";

// Base biologique pour l'algorithme
const BACTERIA_DATA: Record<string, { mu: number; tOpt: number; phOpt: number; k_base: number; description: string }> = {
  [BacteriaType.E_COLI]: { mu: 0.9, tOpt: 37, phOpt: 7.0, k_base: 4.5, description: "Bactérie modèle à croissance rapide." },
  [BacteriaType.B_SUBTILIS]: { mu: 0.7, tOpt: 30, phOpt: 7.0, k_base: 3.8, description: "Gram+, sporulante, croissance modérée." },
  [BacteriaType.S_CEREVISIAE]: { mu: 0.45, tOpt: 30, phOpt: 5.5, k_base: 8.0, description: "Levure, croissance diauxique possible." },
  [BacteriaType.P_AERUGINOSA]: { mu: 0.8, tOpt: 37, phOpt: 7.0, k_base: 4.0, description: "Pathogène opportuniste, aérobie strict." },
  [BacteriaType.CUSTOM]: { mu: 0.6, tOpt: 35, phOpt: 7.0, k_base: 4.0, description: "Souche non spécifiée." },
};

const MEDIUM_DATA: Record<string, { nutrientFactor: number; bufferCapacity: number; name: string }> = {
  [MediumType.LB]: { nutrientFactor: 1.0, bufferCapacity: 0.4, name: "LB" },
  [MediumType.TB]: { nutrientFactor: 2.2, bufferCapacity: 0.9, name: "Terrific Broth" },
  [MediumType.MINIMAL]: { nutrientFactor: 0.5, bufferCapacity: 0.2, name: "Minimal" },
  [MediumType.YPD]: { nutrientFactor: 1.8, bufferCapacity: 0.5, name: "YPD" },
  [MediumType.CUSTOM]: { nutrientFactor: 1.0, bufferCapacity: 0.5, name: "Custom" },
};

export const simulateCulture = async (params: SimulationParams): Promise<SimulationResult> => {
  // Simulation d'un temps de calcul pour l'UX
  await new Promise(resolve => setTimeout(resolve, 800));

  const bacteria = BACTERIA_DATA[params.bacteria] || BACTERIA_DATA[BacteriaType.CUSTOM];
  const medium = MEDIUM_DATA[params.medium] || MEDIUM_DATA[MediumType.CUSTOM];

  // 1. Calcul des Facteurs Environnementaux (0.0 - 1.0)
  
  // Température: Modèle gaussien simplifié
  const tempDiff = Math.abs(params.temperature - bacteria.tOpt);
  let tempFactor = Math.exp(-(Math.pow(tempDiff, 2)) / (2 * Math.pow(8, 2))); // sigma = 8
  if (params.temperature > bacteria.tOpt + 10) tempFactor *= 0.1; // Chute rapide si trop chaud

  // pH: Modèle parabolique
  const phDiff = Math.abs(params.ph - bacteria.phOpt);
  let phFactor = 1 - Math.pow(phDiff / 3.5, 2);
  phFactor = Math.max(0, phFactor);

  // Agitation: Facteur limitant O2
  let agitationFactor = Math.min(1.0, params.agitation / 200);
  if (params.bacteria === BacteriaType.S_CEREVISIAE) agitationFactor = Math.min(1.0, 0.5 + params.agitation / 400);

  // 2. Paramètres cinétiques effectifs
  const effectiveMu = bacteria.mu * tempFactor * phFactor * medium.nutrientFactor * agitationFactor;
  const carryingCapacity = bacteria.k_base * medium.nutrientFactor * (0.5 + 0.5 * phFactor);

  // 3. Génération des données temporelles (Modèle Logistique Modifié)
  const growthData: TimePointData[] = [];
  let currentOD = 0.05; // OD initial (inoculum)
  const lagTime = 2 + (1 - tempFactor) * 5 + (1 - phFactor) * 3; // Latence sensible au stress

  // Variables pour détecter les phases
  const phases: PhaseBoundaries = {
    lagEnd: null,
    stationaryStart: null,
    deathStart: null
  };

  const stationaryThreshold = 0.95 * carryingCapacity;
  const deathTimeThreshold = lagTime + (carryingCapacity / (effectiveMu || 0.1)) + 12;

  for (let t = 0; t <= params.duration; t += 1) { // Pas de temps de 1h pour plus de précision
    let phase = "Latence";
    let metabolites = "Adaptation";
    let growthRate = 0;

    // Logique de Phase
    if (t < lagTime) {
      phase = "Latence";
      growthRate = 0;
    } else {
      // Modèle de Monod / Logistique
      const logisticTerm = 1 - (currentOD / carryingCapacity);
      if (logisticTerm > 0) {
        growthRate = effectiveMu * logisticTerm;
        const delta = currentOD * growthRate; 
        currentOD += delta; 
      }

      if (currentOD < 0.2) phase = "Latence";
      else if (currentOD < stationaryThreshold) phase = "Exponentielle";
      else phase = "Stationnaire";

      // Phase de déclin
      if (phase === "Stationnaire" && t > deathTimeThreshold) {
        phase = "Déclin";
        currentOD *= 0.97; // Lyse cellulaire
      }
    }

    // Capture des transitions de phase
    if (phase === "Exponentielle" && phases.lagEnd === null) phases.lagEnd = t;
    if (phase === "Stationnaire" && phases.stationaryStart === null) phases.stationaryStart = t;
    if (phase === "Déclin" && phases.deathStart === null) phases.deathStart = t;

    // Métabolites dynamiques
    if (phase === "Latence") metabolites = "Synthèse ARN/Enzymes";
    else if (phase === "Exponentielle") metabolites = "Conso. Glc/N";
    else if (phase === "Stationnaire") metabolites = "Acides Organiques";
    else if (phase === "Déclin") metabolites = "Protéases/Toxines";

    // Calcul CFU
    let cfu = 0;
    if (currentOD > 0.01) {
      cfu = Math.log10(currentOD * 8e8);
    }

    // Filtrage pour ne garder que les points pairs pour l'affichage graphique si trop long
    // Mais on garde tout pour l'export CSV. Pour le graph on peut passer tout le tableau, Recharts gère.
    growthData.push({
      hour: t,
      od600: parseFloat(currentOD.toFixed(3)),
      cfu: parseFloat(cfu.toFixed(2)),
      phase,
      metabolites
    });
  }

  // 4. Agent Algorithmique (Logique conditionnelle stricte et détaillée)
  const generateAnalysis = (hour: number): CheckpointAnalysis => {
    // Trouver le point le plus proche si l'heure exacte n'existe pas (ex: pas de 1h)
    // Ici on a step=1 donc ça devrait aller.
    const point = growthData.find(d => d.hour === hour);
    
    // Si la simulation est plus courte que le checkpoint demandé
    if (!point) return { status: "Non atteint", risks: "-", actions: [] };

    const analysis: CheckpointAnalysis = {
      status: `Phase ${point.phase} (OD ${point.od600})`,
      risks: "",
      actions: []
    };

    if (point.phase === "Latence") {
      analysis.risks = "Risque de contamination externe si latence > 4h.";
      analysis.actions = ["Vérifier calibration sonde pH", "Ne pas ajouter d'antibiotiques maintenant"];
    } else if (point.phase === "Exponentielle") {
      analysis.risks = "Épuisement rapide de l'oxygène dissous (DO).";
      analysis.actions = [
        point.od600 > 0.8 ? "Augmenter agitation (+10%)" : "Maintenir agitation",
        "Surveiller formation de mousse",
        "Induction possible (IPTG/Arabinose)"
      ];
    } else if (point.phase === "Stationnaire") {
      analysis.risks = "Accumulation d'acétate et acidification.";
      analysis.actions = [
        "Débuter la récolte (Centrifugation)",
        "Réduire T°C pour préserver protéines",
        "Stopper alimentation (Batch)"
      ];
    } else if (point.phase === "Déclin") {
      analysis.risks = "Lyse cellulaire et dégradation produit.";
      analysis.actions = ["Arrêt immédiat du bioréacteur", "Traitement des déchets biologiques"];
    }

    return analysis;
  };

  // 5. Recommandation Globale Enrichie
  const peakOD = Math.max(...growthData.map(d => d.od600)).toFixed(2);
  const peakTime = growthData.find(d => d.od600 > parseFloat(peakOD) * 0.98)?.hour;

  let summaryText = `Culture simulée de ${params.bacteria} sur ${params.duration}h. `;
  summaryText += `Phase exponentielle observée de ${phases.lagEnd || '?'}h à ${phases.stationaryStart || '?'}h. `;
  summaryText += `Biomasse maximale (OD ${peakOD}) atteinte vers T=${peakTime}h.`;

  let optimizationAdvice = "";
  if (effectiveMu < 0.2) {
    optimizationAdvice = "Taux de croissance critique faible. Suggestions : 1) Vérifier que la T°C est proche de l'optimum (" + bacteria.tOpt + "°C). 2) Le pH actuel (" + params.ph + ") pourrait inhiber la souche.";
  } else if (phases.stationaryStart && phases.stationaryStart < 10) {
    optimizationAdvice = "Entrée en phase stationnaire précoce. Suggestion : Utiliser un milieu plus riche (TB ou Fed-batch) pour prolonger la phase exponentielle.";
  } else {
    optimizationAdvice = "Profil cinétique robuste. Pour l'échelle industrielle : Envisager une stratégie d'alimentation (Fed-batch) exponentielle pour maintenir mu constant.";
  }

  const agentRec: AgentRecommendation = {
    summary: summaryText,
    optimization: optimizationAdvice,
    safety: params.bacteria === BacteriaType.P_AERUGINOSA 
      ? "Niveau de Biosécurité 2 (BSL-2). Manipulation sous PSM obligatoire. Décontamination stricte des effluents."
      : "Niveau de Biosécurité 1 (BSL-1). Port de la blouse et des gants recommandé. Nettoyage standard à l'éthanol 70%."
  };

  return {
    growthData,
    phases,
    checkpoints: {
      h12: generateAnalysis(12),
      h24: generateAnalysis(24),
      h36: generateAnalysis(36)
    },
    agentRecommendation: agentRec
  };
};