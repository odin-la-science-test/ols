import { BiochemicalTest, GalleryResult, GenomicMatch } from "../types";

// --- Moteur d'Identification Génomique (Algo: Jaccard K-mers) ---

const GENOMIC_DATABASE: Record<string, string> = {
  "Escherichia coli": "AGAGTTTGATCATGGCTCAGATTGAACGCTGGCGGCAGGCCTAACACATGCAAGTCGAACGGTAACAGGA",
  "Bacillus subtilis": "AGAGTTTGATCCTGGCTCAGGACGAACGCTGGCGGCGTGCCTAATACATGCAAGTCGAGCGGACAGATGG",
  "Pseudomonas aeruginosa": "AGAGTTTGATCATGGCTCAGATTGAACGCTGGCGGCAGGCCTAACACATGCAAGTCGAGCGGATGAAGGG",
  "Saccharomyces cerevisiae": "TACCTGGTTGATCCTGCCAGTAGTCATATGCTTGTCTCAAAGATTAAGCCATGCATGTCTAAGTATAAGC",
  "Staphylococcus aureus": "TACCTGGTTGATCCTGCCAGTAGTCATATGCTTGTCTCAAAGATTAAGCCATGCATGTCTAAGTATAAGC" // Placeholder partiel
};

export const identifyGenomic = (sequence: string): GenomicMatch[] => {
  // Nettoyage de l'entrée (FASTA header removal, whitespace, uppercase)
  const cleanSeq = sequence.replace(/^>.*\n/, '').replace(/\s/g, '').toUpperCase();
  
  if (cleanSeq.length < 20) return [];

  const results: GenomicMatch[] = [];
  const k = 6; // Taille des k-mers

  // Génération des k-mers pour l'entrée
  const inputKmers = new Set<string>();
  for (let i = 0; i < cleanSeq.length - k + 1; i++) {
    inputKmers.add(cleanSeq.substring(i, i + k));
  }

  // Comparaison avec la base de données
  Object.entries(GENOMIC_DATABASE).forEach(([organism, dbSeq]) => {
    const dbKmers = new Set<string>();
    for (let i = 0; i < dbSeq.length - k + 1; i++) {
      dbKmers.add(dbSeq.substring(i, i + k));
    }

    // Indice de Jaccard (Intersection / Union)
    let intersection = 0;
    inputKmers.forEach(kmer => {
      if (dbKmers.has(kmer)) intersection++;
    });

    const union = inputKmers.size + dbKmers.size - intersection;
    const similarity = (intersection / union) * 100;

    // Boost artificiel pour la démo si correspondance exacte de sous-chaîne
    let finalScore = similarity;
    if (cleanSeq.includes(dbSeq) || dbSeq.includes(cleanSeq)) {
        finalScore = 100;
    } else if (finalScore > 0) {
        // Normalisation pour l'affichage (Jaccard est souvent bas sur des séquences courtes)
        finalScore = Math.min(99.9, finalScore * 2.5);
    }

    if (finalScore > 15) { // Seuil minimal
        results.push({
            organism,
            similarity: parseFloat(finalScore.toFixed(1)),
            description: finalScore > 90 ? "Identification certaine (16S rRNA)" : "Homologie partielle détectée"
        });
    }
  });

  return results.sort((a, b) => b.similarity - a.similarity);
};

// --- Moteur d'Identification Biochimique (Algo: Code numérique) ---

// Base de données simplifiée de profils (Codes types pour API 20E/NE simulés)
const GALLERY_DB: Record<string, string> = {
  "5144572": "Escherichia coli",
  "5044552": "Escherichia coli (Atypique)",
  "0000000": "Non fermentant / Inerte",
  "2206004": "Pseudomonas aeruginosa",
  "6350100": "Proteus mirabilis",
  "1204000": "Salmonella sp."
};

// Algorithme de calcul du code numérique (Logique API: groupes de 3 tests, somme valeurs 1-2-4)
export const calculateProfileCode = (tests: BiochemicalTest[]): string => {
  let code = "";
  // On suppose 21 tests divisés en 7 groupes de 3
  for (let i = 1; i <= 7; i++) {
    const groupTests = tests.filter(t => t.group === i);
    let groupScore = 0;
    groupTests.forEach(t => {
      if (t.positive) groupScore += t.value;
    });
    code += groupScore.toString();
  }
  return code;
};

export const identifyGallery = (tests: BiochemicalTest[]): GalleryResult => {
  const code = calculateProfileCode(tests);
  const match = GALLERY_DB[code];

  if (match) {
    return {
      code,
      organism: match,
      probability: 99.9,
      confidence: "Élevée"
    };
  }

  // Recherche du plus proche voisin (Distance de Hamming sur le code)
  let bestDist = 100;
  let bestMatch = "Inconnu";
  
  Object.keys(GALLERY_DB).forEach(dbCode => {
    let dist = 0;
    for(let i=0; i<code.length; i++) {
        if(code[i] !== dbCode[i]) dist++;
    }
    if (dist < bestDist) {
        bestDist = dist;
        bestMatch = GALLERY_DB[dbCode];
    }
  });

  if (bestDist <= 2) {
      return {
          code,
          organism: bestMatch + " (Probable)",
          probability: Math.max(0, 100 - (bestDist * 20)),
          confidence: bestDist === 1 ? "Moyenne" : "Faible"
      };
  }

  return {
    code,
    organism: "Profil Inconnu",
    probability: 0,
    confidence: "Faible"
  };
};

// Données initiales pour la galerie (21 tests standards)
export const INITIAL_GALLERY_TESTS: BiochemicalTest[] = [
    // Groupe 1
    { id: "ONPG", name: "ONPG", description: "Bêta-galactosidase", group: 1, value: 1, positive: false },
    { id: "ADH", name: "ADH", description: "Arginine Dihydrolase", group: 1, value: 2, positive: false },
    { id: "LDC", name: "LDC", description: "Lysine Décarboxylase", group: 1, value: 4, positive: false },
    // Groupe 2
    { id: "ODC", name: "ODC", description: "Ornithine Décarboxylase", group: 2, value: 1, positive: false },
    { id: "CIT", name: "CIT", description: "Utilisation Citrate", group: 2, value: 2, positive: false },
    { id: "H2S", name: "H2S", description: "Production H2S", group: 2, value: 4, positive: false },
    // Groupe 3
    { id: "URE", name: "URE", description: "Uréase", group: 3, value: 1, positive: false },
    { id: "TDA", name: "TDA", description: "Tryptophane Désaminase", group: 3, value: 2, positive: false },
    { id: "IND", name: "IND", description: "Production Indole", group: 3, value: 4, positive: false },
    // Groupe 4
    { id: "VP", name: "VP", description: "Acétoïne (Voges-Proskauer)", group: 4, value: 1, positive: false },
    { id: "GEL", name: "GEL", description: "Gélatinase", group: 4, value: 2, positive: false },
    { id: "GLU", name: "GLU", description: "Glucose", group: 4, value: 4, positive: false },
    // Groupe 5
    { id: "MAN", name: "MAN", description: "Mannitol", group: 5, value: 1, positive: false },
    { id: "INO", name: "INO", description: "Inositol", group: 5, value: 2, positive: false },
    { id: "SOR", name: "SOR", description: "Sorbitol", group: 5, value: 4, positive: false },
    // Groupe 6
    { id: "RHA", name: "RHA", description: "Rhamnose", group: 6, value: 1, positive: false },
    { id: "SAC", name: "SAC", description: "Saccharose", group: 6, value: 2, positive: false },
    { id: "MEL", name: "MEL", description: "Melibiose", group: 6, value: 4, positive: false },
    // Groupe 7
    { id: "AMY", name: "AMY", description: "Amygdalin", group: 7, value: 1, positive: false },
    { id: "ARA", name: "ARA", description: "Arabinose", group: 7, value: 2, positive: false },
    { id: "OX", name: "OX", description: "Oxydase (Test sup.)", group: 7, value: 4, positive: false },
];