export interface SimulationParams {
  bacteria: string;
  medium: string;
  temperature: number;
  ph: number;
  agitation: number;
  duration: number;
}

export interface TimePointData {
  hour: number;
  od600: number; // Optical Density
  cfu: number;   // Log10 CFU/mL
  phase: string; // Latence, Exponentielle, Stationnaire, Déclin
  metabolites: string; // Key metabolites produced/consumed
}

export interface CheckpointAnalysis {
  status: string;
  risks: string;
  actions: string[];
}

export interface AgentRecommendation {
  summary: string;
  optimization: string;
  safety: string;
}

export interface PhaseBoundaries {
  lagEnd: number | null;
  stationaryStart: number | null;
  deathStart: number | null;
}

export interface SimulationResult {
  growthData: TimePointData[];
  checkpoints: {
    h12: CheckpointAnalysis;
    h24: CheckpointAnalysis;
    h36: CheckpointAnalysis;
  };
  agentRecommendation: AgentRecommendation;
  phases: PhaseBoundaries;
}

// --- Nouveaux Types pour Identification ---

export interface GenomicMatch {
  organism: string;
  similarity: number; // 0-100
  description: string;
}

export interface BiochemicalTest {
  id: string;
  name: string;
  description: string;
  group: number; // Pour le calcul du code (triplets)
  value: number; // 1, 2, ou 4
  positive: boolean;
}

export interface GalleryResult {
  code: string;
  organism: string;
  probability: number;
  confidence: "Élevée" | "Moyenne" | "Faible";
}

export enum BacteriaType {
  E_COLI = "Escherichia coli",
  B_SUBTILIS = "Bacillus subtilis",
  S_CEREVISIAE = "Saccharomyces cerevisiae",
  P_AERUGINOSA = "Pseudomonas aeruginosa",
  CUSTOM = "Autre (Spécifier)"
}

export enum MediumType {
  LB = "Lysogeny Broth (LB)",
  MINIMAL = "M9 Minimal Media",
  TB = "Terrific Broth",
  YPD = "YPD Broth",
  CUSTOM = "Autre (Spécifier)"
}