import React, { useState } from 'react';
import { InputForm } from './components/InputForm';
import { GrowthChart } from './components/GrowthChart';
import { CheckpointCard } from './components/CheckpointCard';
import { AgentAdvice } from './components/AgentAdvice';
import { GenomicID } from './components/GenomicID';
import { GalleryID } from './components/GalleryID';
import { simulateCulture } from './services/gemini';
import { SimulationParams, SimulationResult } from './types';
import { Dna, AlertCircle, Download, Activity, FlaskConical, Search } from 'lucide-react';

type ViewMode = 'simulation' | 'genomic' | 'gallery';

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<ViewMode>('simulation');
  const [result, setResult] = useState<SimulationResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSimulation = async (params: SimulationParams) => {
    setLoading(true);
    setError(null);
    setResult(null);
    try {
      const data = await simulateCulture(params);
      setResult(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Une erreur inconnue est survenue");
    } finally {
      setLoading(false);
    }
  };

  const downloadCSV = () => {
    if (!result) return;
    const headers = ["Heure,Phase,OD600,Log_CFU,Metabolites"];
    const rows = result.growthData.map(d => 
      `${d.hour},${d.phase},${d.od600},${d.cfu},${d.metabolites}`
    );
    const csvContent = "data:text/csv;charset=utf-8," + [headers, ...rows].join("\n");
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", "biopredict_data.csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="min-h-screen pb-12 bg-slate-50 font-sans">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-30 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="bg-teal-600 p-2 rounded-lg shadow-sm">
              <Dna className="w-6 h-6 text-white" />
            </div>
            <h1 className="text-xl font-bold text-slate-800 tracking-tight">BioPredict <span className="text-teal-600 font-light">Suite v2.1</span></h1>
          </div>
          
          {/* Navigation Tabs */}
          <nav className="hidden md:flex space-x-1 bg-slate-100 p-1 rounded-lg">
            <button
                onClick={() => setCurrentView('simulation')}
                className={`px-4 py-2 rounded-md text-sm font-medium transition-all ${
                    currentView === 'simulation' 
                    ? 'bg-white text-teal-700 shadow-sm' 
                    : 'text-slate-600 hover:text-slate-800 hover:bg-slate-200'
                }`}
            >
                <div className="flex items-center gap-2"><Activity className="w-4 h-4"/> Simulation</div>
            </button>
            <button
                onClick={() => setCurrentView('genomic')}
                className={`px-4 py-2 rounded-md text-sm font-medium transition-all ${
                    currentView === 'genomic' 
                    ? 'bg-white text-purple-700 shadow-sm' 
                    : 'text-slate-600 hover:text-slate-800 hover:bg-slate-200'
                }`}
            >
                <div className="flex items-center gap-2"><Search className="w-4 h-4"/> Génomique</div>
            </button>
            <button
                onClick={() => setCurrentView('gallery')}
                className={`px-4 py-2 rounded-md text-sm font-medium transition-all ${
                    currentView === 'gallery' 
                    ? 'bg-white text-orange-700 shadow-sm' 
                    : 'text-slate-600 hover:text-slate-800 hover:bg-slate-200'
                }`}
            >
                <div className="flex items-center gap-2"><FlaskConical className="w-4 h-4"/> Galerie</div>
            </button>
          </nav>
        </div>
        
        {/* Mobile Nav (Simple bar below) */}
        <div className="md:hidden flex justify-around border-t border-slate-100 bg-white">
            <button onClick={() => setCurrentView('simulation')} className={`flex-1 py-3 text-xs font-medium ${currentView === 'simulation' ? 'text-teal-600 border-b-2 border-teal-600' : 'text-slate-500'}`}>Simulation</button>
            <button onClick={() => setCurrentView('genomic')} className={`flex-1 py-3 text-xs font-medium ${currentView === 'genomic' ? 'text-purple-600 border-b-2 border-purple-600' : 'text-slate-500'}`}>Génomique</button>
            <button onClick={() => setCurrentView('gallery')} className={`flex-1 py-3 text-xs font-medium ${currentView === 'gallery' ? 'text-orange-600 border-b-2 border-orange-600' : 'text-slate-500'}`}>Galerie</button>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        
        {/* View: Simulation */}
        {currentView === 'simulation' && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 animate-fade-in">
            {/* Left Sidebar: Controls */}
            <div className="lg:col-span-4 space-y-6">
                <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
                <h3 className="font-semibold text-slate-800 mb-2">Simulation Cinétique</h3>
                <p className="text-sm text-slate-600 leading-relaxed">
                    Prédiction algorithmique basée sur les modèles de Monod et Luedeking-Piret.
                </p>
                </div>
                
                <InputForm onSubmit={handleSimulation} isLoading={loading} />
                
                {error && (
                <div className="bg-red-50 border border-red-200 p-4 rounded-lg flex items-start gap-3 text-red-700 animate-pulse">
                    <AlertCircle className="w-5 h-5 flex-shrink-0 mt-0.5" />
                    <div>
                    <h4 className="font-semibold">Erreur de simulation</h4>
                    <p className="text-sm">{error}</p>
                    </div>
                </div>
                )}
            </div>

            {/* Right Area: Results */}
            <div className="lg:col-span-8 space-y-8">
                {!result && !loading && (
                <div className="h-full flex flex-col items-center justify-center text-slate-400 border-2 border-dashed border-slate-300 rounded-2xl min-h-[400px] bg-white/50">
                    <div className="bg-slate-100 p-6 rounded-full mb-4">
                    <Activity className="w-12 h-12 opacity-50 text-slate-500" />
                    </div>
                    <p className="text-lg font-medium text-slate-600">En attente de paramètres...</p>
                    <p className="text-sm">Configurez votre bioréacteur à gauche.</p>
                </div>
                )}

                {loading && (
                <div className="h-full flex flex-col items-center justify-center min-h-[400px] bg-white rounded-2xl shadow-sm border border-slate-200">
                    <div className="relative mb-6">
                    <div className="animate-spin rounded-full h-16 w-16 border-t-4 border-b-4 border-teal-600"></div>
                    <div className="absolute inset-0 flex items-center justify-center">
                        <Dna className="w-6 h-6 text-teal-600 opacity-50" />
                    </div>
                    </div>
                    <h3 className="text-xl font-semibold text-slate-700">Calcul en cours...</h3>
                    <p className="text-slate-500 mt-2 text-center max-w-md px-4">
                    Résolution des équations différentielles...
                    </p>
                </div>
                )}

                {result && (
                <div className="space-y-8 animate-fade-in">
                    {/* 1. Main Chart Section */}
                    <div className="bg-white p-6 rounded-xl shadow-md border border-slate-200 relative">
                    <div className="flex justify-between items-center mb-6">
                        <div>
                        <h3 className="text-lg font-bold text-slate-800">Courbe de Croissance</h3>
                        <p className="text-sm text-slate-500">Visualisation dynamique des phases</p>
                        </div>
                        <button 
                        onClick={downloadCSV}
                        className="flex items-center gap-2 px-3 py-1.5 text-sm font-medium text-teal-700 bg-teal-50 hover:bg-teal-100 rounded-md border border-teal-200 transition-colors"
                        >
                        <Download className="w-4 h-4" />
                        Export CSV
                        </button>
                    </div>
                    <GrowthChart data={result.growthData} phases={result.phases} />
                    </div>

                    {/* 2. Checkpoint Cards Grid */}
                    <div>
                    <h3 className="text-lg font-bold text-slate-800 mb-4 px-1">Points de Contrôle Stratégiques</h3>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        {result.growthData.some(d => d.hour >= 12) && (
                        <CheckpointCard 
                            hour={12} 
                            analysis={result.checkpoints.h12} 
                            dataPoint={result.growthData.find(d => d.hour === 12)}
                        />
                        )}
                        {result.growthData.some(d => d.hour >= 24) && (
                        <CheckpointCard 
                            hour={24} 
                            analysis={result.checkpoints.h24} 
                            dataPoint={result.growthData.find(d => d.hour === 24)}
                        />
                        )}
                        {result.growthData.some(d => d.hour >= 36) && (
                        <CheckpointCard 
                            hour={36} 
                            analysis={result.checkpoints.h36} 
                            dataPoint={result.growthData.find(d => d.hour === 36)}
                        />
                        )}
                    </div>
                    </div>

                    {/* 3. Agent Advice */}
                    <AgentAdvice recommendation={result.agentRecommendation} />
                </div>
                )}
            </div>
            </div>
        )}

        {/* View: Genomic */}
        {currentView === 'genomic' && <GenomicID />}

        {/* View: Gallery */}
        {currentView === 'gallery' && <GalleryID />}

      </main>
    </div>
  );
};

export default App;