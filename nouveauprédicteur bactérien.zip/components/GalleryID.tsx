import React, { useState } from 'react';
import { BiochemicalTest, GalleryResult } from '../types';
import { identifyGallery, INITIAL_GALLERY_TESTS } from '../services/identification';
import { FlaskConical, RotateCcw, Check, HelpCircle } from 'lucide-react';

export const GalleryID: React.FC = () => {
  const [tests, setTests] = useState<BiochemicalTest[]>(INITIAL_GALLERY_TESTS);
  const [result, setResult] = useState<GalleryResult | null>(null);

  const toggleTest = (id: string) => {
    const newTests = tests.map(t => t.id === id ? { ...t, positive: !t.positive } : t);
    setTests(newTests);
    // Identification en temps réel
    setResult(identifyGallery(newTests));
  };

  const resetGallery = () => {
      const newTests = tests.map(t => ({...t, positive: false}));
      setTests(newTests);
      setResult(identifyGallery(newTests));
  };

  const loadPreset = () => {
      // Preset E. coli
      const presetIds = ["ONPG", "LDC", "ODC", "IND", "GLU", "MAN", "SOR", "RHA", "ARA", "MEL"];
      const newTests = tests.map(t => ({
          ...t,
          positive: presetIds.includes(t.id)
      }));
      setTests(newTests);
      setResult(identifyGallery(newTests));
  };

  return (
    <div className="space-y-8 animate-fade-in">
      
      {/* Header & Controls */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
        <div>
            <h2 className="text-xl font-bold text-slate-800 flex items-center gap-2">
                <FlaskConical className="w-6 h-6 text-orange-600" />
                Galerie Biochimique
            </h2>
            <p className="text-sm text-slate-500 mt-1">
                Simulateur de galerie type "API 20E". Cliquez sur les cupules pour marquer positif (+).
            </p>
        </div>
        <div className="flex gap-2">
            <button onClick={loadPreset} className="text-sm px-3 py-2 bg-slate-100 text-slate-700 rounded hover:bg-slate-200 transition">
                Demo E. coli
            </button>
            <button onClick={resetGallery} className="text-sm px-3 py-2 bg-slate-100 text-slate-700 rounded hover:bg-slate-200 transition flex items-center gap-1">
                <RotateCcw className="w-4 h-4" /> Reset
            </button>
        </div>
      </div>

      {/* The Gallery Strip Visual */}
      <div className="overflow-x-auto pb-4">
        <div className="flex gap-1 min-w-max p-2">
            {tests.map((test, idx) => (
                <div key={test.id} className="flex flex-col items-center gap-2 group relative">
                    {/* Tooltip */}
                    <div className="absolute bottom-full mb-2 hidden group-hover:block w-32 bg-slate-800 text-white text-xs p-2 rounded z-10 text-center">
                        {test.description} (Val: {test.value})
                    </div>

                    {/* Separator for groups */}
                    {(idx > 0 && idx % 3 === 0) && <div className="w-4"></div>}

                    {/* Cupule */}
                    <button
                        onClick={() => toggleTest(test.id)}
                        className={`w-12 h-16 rounded-full rounded-t-none border-2 flex items-end justify-center pb-2 transition-all shadow-sm
                        ${test.positive 
                            ? 'bg-gradient-to-b from-yellow-200 to-orange-400 border-orange-500 shadow-orange-200' 
                            : 'bg-gradient-to-b from-transparent to-slate-100 border-slate-300 hover:border-slate-400'
                        }`}
                    >
                        {test.positive && <Check className="w-4 h-4 text-white drop-shadow-md" />}
                    </button>
                    
                    {/* Label */}
                    <span className={`text-xs font-bold font-mono ${test.positive ? 'text-orange-600' : 'text-slate-500'}`}>
                        {test.id}
                    </span>
                    
                    {/* +/- Indicator */}
                    <span className="text-[10px] text-slate-400">{test.positive ? '+' : '-'}</span>
                </div>
            ))}
        </div>
      </div>

      {/* Result Card */}
      {result && (
         <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-lg flex flex-col md:flex-row items-center justify-between gap-6 transition-all">
            <div className="flex items-center gap-4">
                <div className={`w-16 h-16 rounded-full flex items-center justify-center text-xl font-bold border-4
                    ${result.confidence === 'Élevée' ? 'border-green-500 bg-green-50 text-green-700' : 
                      result.confidence === 'Moyenne' ? 'border-yellow-500 bg-yellow-50 text-yellow-700' : 
                      'border-red-500 bg-red-50 text-red-700'
                    }`}>
                    {result.probability > 0 ? `${Math.floor(result.probability)}%` : '?'}
                </div>
                <div>
                    <div className="text-xs text-slate-500 uppercase tracking-wide font-semibold mb-1">Résultat d'identification</div>
                    <div className="text-2xl font-bold text-slate-800">{result.organism}</div>
                    <div className="text-sm text-slate-500 font-mono mt-1">Code Profil: <span className="bg-slate-100 px-2 py-0.5 rounded text-slate-700">{result.code}</span></div>
                </div>
            </div>

            <div className="flex gap-4 text-sm">
                <div className="text-right">
                    <span className="block text-slate-400 text-xs">Confiance</span>
                    <span className={`font-semibold ${
                         result.confidence === 'Élevée' ? 'text-green-600' : 
                         result.confidence === 'Moyenne' ? 'text-yellow-600' : 
                         'text-red-600'
                    }`}>{result.confidence}</span>
                </div>
            </div>
         </div>
      )}
    </div>
  );
};