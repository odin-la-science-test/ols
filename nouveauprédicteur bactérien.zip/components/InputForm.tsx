import React, { useState } from 'react';
import { BacteriaType, MediumType, SimulationParams } from '../types';
import { Beaker, Thermometer, Wind, Droplets, Play, Loader2 } from 'lucide-react';

interface InputFormProps {
  onSubmit: (params: SimulationParams) => void;
  isLoading: boolean;
}

export const InputForm: React.FC<InputFormProps> = ({ onSubmit, isLoading }) => {
  const [params, setParams] = useState<SimulationParams>({
    bacteria: BacteriaType.E_COLI,
    medium: MediumType.LB,
    temperature: 37,
    ph: 7.0,
    agitation: 200,
    duration: 48,
  });

  const [customBacteria, setCustomBacteria] = useState("");
  const [customMedium, setCustomMedium] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const finalParams = { ...params };
    if (params.bacteria === BacteriaType.CUSTOM) finalParams.bacteria = customBacteria;
    if (params.medium === MediumType.CUSTOM) finalParams.medium = customMedium;
    onSubmit(finalParams);
  };

  return (
    <form onSubmit={handleSubmit} className="bg-white p-6 rounded-xl shadow-lg border border-slate-200">
      <h2 className="text-xl font-bold text-slate-800 mb-6 flex items-center gap-2">
        <Beaker className="w-6 h-6 text-teal-600" />
        Paramètres de Culture
      </h2>

      <div className="space-y-5">
        {/* Bacteria Selection */}
        <div>
          <label className="block text-sm font-medium text-slate-600 mb-1">Micro-organisme</label>
          <select
            value={params.bacteria}
            onChange={(e) => setParams({ ...params, bacteria: e.target.value })}
            className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg focus:ring-2 focus:ring-teal-500 outline-none transition"
          >
            {Object.values(BacteriaType).map((b) => (
              <option key={b} value={b}>{b}</option>
            ))}
          </select>
          {params.bacteria === BacteriaType.CUSTOM && (
            <input
              type="text"
              placeholder="Nom de la bactérie..."
              className="mt-2 w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg outline-none focus:ring-2 focus:ring-teal-500"
              value={customBacteria}
              onChange={(e) => setCustomBacteria(e.target.value)}
              required
            />
          )}
        </div>

        {/* Medium Selection */}
        <div>
          <label className="block text-sm font-medium text-slate-600 mb-1">Milieu de Culture</label>
          <select
            value={params.medium}
            onChange={(e) => setParams({ ...params, medium: e.target.value })}
            className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg focus:ring-2 focus:ring-teal-500 outline-none transition"
          >
            {Object.values(MediumType).map((m) => (
              <option key={m} value={m}>{m}</option>
            ))}
          </select>
          {params.medium === MediumType.CUSTOM && (
            <input
              type="text"
              placeholder="Composition du milieu..."
              className="mt-2 w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg outline-none focus:ring-2 focus:ring-teal-500"
              value={customMedium}
              onChange={(e) => setCustomMedium(e.target.value)}
              required
            />
          )}
        </div>

        {/* Physical Conditions Grid */}
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-slate-600 mb-1 flex items-center gap-1">
              <Thermometer className="w-4 h-4" /> Temp. (°C)
            </label>
            <input
              type="number"
              step="0.1"
              value={params.temperature}
              onChange={(e) => setParams({ ...params, temperature: parseFloat(e.target.value) })}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg focus:ring-2 focus:ring-teal-500 outline-none"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-600 mb-1 flex items-center gap-1">
              <Droplets className="w-4 h-4" /> pH Initial
            </label>
            <input
              type="number"
              step="0.1"
              value={params.ph}
              onChange={(e) => setParams({ ...params, ph: parseFloat(e.target.value) })}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg focus:ring-2 focus:ring-teal-500 outline-none"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-600 mb-1 flex items-center gap-1">
              <Wind className="w-4 h-4" /> Agitation (RPM)
            </label>
            <input
              type="number"
              value={params.agitation}
              onChange={(e) => setParams({ ...params, agitation: parseInt(e.target.value) })}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg focus:ring-2 focus:ring-teal-500 outline-none"
            />
          </div>
          <div>
             <label className="block text-sm font-medium text-slate-600 mb-1">Durée (Heures)</label>
            <input
              type="number"
              value={params.duration}
              onChange={(e) => setParams({ ...params, duration: parseInt(e.target.value) })}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg focus:ring-2 focus:ring-teal-500 outline-none"
            />
          </div>
        </div>

        <button
          type="submit"
          disabled={isLoading}
          className={`w-full py-3 px-4 rounded-lg text-white font-semibold shadow-md transition-all flex items-center justify-center gap-2
            ${isLoading ? 'bg-slate-400 cursor-not-allowed' : 'bg-teal-600 hover:bg-teal-700 hover:shadow-lg'}`}
        >
          {isLoading ? (
            <>
              <Loader2 className="w-5 h-5 animate-spin" />
              Simulation en cours...
            </>
          ) : (
            <>
              <Play className="w-5 h-5" />
              Lancer la Simulation
            </>
          )}
        </button>
      </div>
    </form>
  );
};