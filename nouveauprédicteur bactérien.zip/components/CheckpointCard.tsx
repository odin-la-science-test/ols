import React from 'react';
import { CheckpointAnalysis, TimePointData } from '../types';
import { Clock, AlertTriangle, CheckCircle2, Activity } from 'lucide-react';

interface CheckpointCardProps {
  hour: number;
  analysis: CheckpointAnalysis;
  dataPoint?: TimePointData;
}

export const CheckpointCard: React.FC<CheckpointCardProps> = ({ hour, analysis, dataPoint }) => {
  if (!analysis) return null;

  return (
    <div className="bg-white rounded-xl shadow-md border border-slate-200 overflow-hidden flex flex-col h-full">
      <div className="bg-slate-50 p-4 border-b border-slate-100 flex justify-between items-center">
        <h3 className="font-bold text-slate-800 flex items-center gap-2">
          <Clock className="w-5 h-5 text-teal-600" />
          Point de Contrôle : {hour}h
        </h3>
        {dataPoint && (
          <span className="text-xs font-mono bg-teal-100 text-teal-800 px-2 py-1 rounded-full">
            OD: {dataPoint.od600}
          </span>
        )}
      </div>
      
      <div className="p-4 space-y-4 flex-grow">
        <div>
          <h4 className="text-xs uppercase tracking-wide text-slate-500 font-semibold mb-1">État de la culture</h4>
          <p className="text-sm text-slate-700 font-medium">{analysis.status}</p>
        </div>

        <div>
           <h4 className="text-xs uppercase tracking-wide text-amber-600 font-semibold mb-1 flex items-center gap-1">
             <AlertTriangle className="w-3 h-3" /> Risques / Points Critiques
           </h4>
           <p className="text-sm text-slate-600">{analysis.risks}</p>
        </div>

        <div>
          <h4 className="text-xs uppercase tracking-wide text-teal-700 font-semibold mb-2 flex items-center gap-1">
            <CheckCircle2 className="w-3 h-3" /> Actions Requises (Agent)
          </h4>
          <ul className="space-y-1">
            {analysis.actions.map((action, idx) => (
              <li key={idx} className="text-sm text-slate-700 flex items-start gap-2 bg-slate-50 p-2 rounded border border-slate-100">
                <Activity className="w-4 h-4 text-teal-500 mt-0.5 flex-shrink-0" />
                {action}
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
};