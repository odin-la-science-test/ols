import React from 'react';
import { AgentRecommendation } from '../types';
import { Bot, Lightbulb, ShieldAlert } from 'lucide-react';

interface AgentAdviceProps {
  recommendation: AgentRecommendation;
}

export const AgentAdvice: React.FC<AgentAdviceProps> = ({ recommendation }) => {
  return (
    <div className="bg-gradient-to-br from-indigo-900 to-slate-900 rounded-xl shadow-xl text-white p-6 relative overflow-hidden">
      {/* Decorative background element */}
      <div className="absolute top-0 right-0 opacity-10 transform translate-x-1/4 -translate-y-1/4">
        <Bot className="w-64 h-64" />
      </div>

      <h2 className="text-2xl font-bold mb-6 flex items-center gap-3 relative z-10">
        <Bot className="w-8 h-8 text-cyan-400" />
        Analyse de l'Agent Algorithmique
      </h2>

      <div className="grid md:grid-cols-3 gap-6 relative z-10">
        <div className="bg-white/10 backdrop-blur-sm p-4 rounded-lg border border-white/20">
          <h3 className="font-semibold text-cyan-300 mb-2">Résumé Cinétique</h3>
          <p className="text-sm leading-relaxed text-slate-200">
            {recommendation.summary}
          </p>
        </div>

        <div className="bg-white/10 backdrop-blur-sm p-4 rounded-lg border border-white/20">
          <h3 className="font-semibold text-yellow-300 mb-2 flex items-center gap-2">
            <Lightbulb className="w-4 h-4" /> Optimisation
          </h3>
          <p className="text-sm leading-relaxed text-slate-200">
            {recommendation.optimization}
          </p>
        </div>

        <div className="bg-white/10 backdrop-blur-sm p-4 rounded-lg border border-white/20">
          <h3 className="font-semibold text-red-300 mb-2 flex items-center gap-2">
            <ShieldAlert className="w-4 h-4" /> Biosécurité
          </h3>
          <p className="text-sm leading-relaxed text-slate-200">
            {recommendation.safety}
          </p>
        </div>
      </div>
    </div>
  );
};