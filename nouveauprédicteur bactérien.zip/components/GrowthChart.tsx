import React from 'react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  ReferenceLine,
  ReferenceArea
} from 'recharts';
import { TimePointData, PhaseBoundaries } from '../types';

interface GrowthChartProps {
  data: TimePointData[];
  phases?: PhaseBoundaries;
}

export const GrowthChart: React.FC<GrowthChartProps> = ({ data, phases }) => {
  const maxTime = data.length > 0 ? data[data.length - 1].hour : 0;

  return (
    <div className="h-[400px] w-full">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart
          data={data}
          margin={{
            top: 20,
            right: 30,
            left: 20,
            bottom: 20,
          }}
        >
          <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
          
          {/* Zones de phases colorées */}
          {phases && (
            <>
              {phases.lagEnd && (
                <ReferenceArea 
                  x1={0} 
                  x2={phases.lagEnd} 
                  fill="#94a3b8" 
                  fillOpacity={0.1} 
                  label={{ value: "Latence", position: 'insideTopLeft', fill: '#64748b', fontSize: 12 }} 
                />
              )}
              {phases.lagEnd && phases.stationaryStart && (
                <ReferenceArea 
                  x1={phases.lagEnd} 
                  x2={phases.stationaryStart} 
                  fill="#2dd4bf" 
                  fillOpacity={0.1}
                  label={{ value: "Exponentielle", position: 'insideTop', fill: '#0d9488', fontSize: 12 }} 
                />
              )}
              {phases.stationaryStart && (
                <ReferenceArea 
                  x1={phases.stationaryStart} 
                  x2={phases.deathStart || maxTime} 
                  fill="#fbbf24" 
                  fillOpacity={0.1}
                  label={{ value: "Stationnaire", position: 'insideTop', fill: '#d97706', fontSize: 12 }} 
                />
              )}
              {phases.deathStart && (
                <ReferenceArea 
                  x1={phases.deathStart} 
                  x2={maxTime} 
                  fill="#f87171" 
                  fillOpacity={0.1}
                  label={{ value: "Déclin", position: 'insideTopRight', fill: '#dc2626', fontSize: 12 }} 
                />
              )}
            </>
          )}

          <XAxis 
            dataKey="hour" 
            label={{ value: 'Temps (h)', position: 'insideBottomRight', offset: -10 }} 
            stroke="#64748b"
          />
          <YAxis 
            yAxisId="left" 
            label={{ value: 'Densité Optique (OD600)', angle: -90, position: 'insideLeft' }} 
            stroke="#0d9488"
          />
          <YAxis 
            yAxisId="right" 
            orientation="right" 
            label={{ value: 'Log10 CFU/mL', angle: 90, position: 'insideRight' }} 
            stroke="#f59e0b"
          />
          <Tooltip 
            contentStyle={{ borderRadius: '8px', border: '1px solid #e2e8f0', boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)' }}
            labelFormatter={(label) => `Temps : ${label}h`}
          />
          <Legend wrapperStyle={{ paddingTop: '20px' }}/>
          
          <Line 
            yAxisId="left"
            type="monotone" 
            dataKey="od600" 
            stroke="#0d9488" 
            name="Biomasse (OD600)" 
            strokeWidth={3}
            dot={false}
            activeDot={{ r: 6 }}
          />
          <Line 
            yAxisId="right"
            type="monotone" 
            dataKey="cfu" 
            stroke="#f59e0b" 
            name="Viabilité (Log CFU)" 
            strokeWidth={2}
            strokeDasharray="5 5"
            dot={false}
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
};