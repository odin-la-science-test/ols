import React, { useState } from 'react';
import { identifyGenomic } from '../services/identification';
import { GenomicMatch } from '../types';
import { Search, Dna, FileText, AlertTriangle } from 'lucide-react';

export const GenomicID: React.FC = () => {
  const [sequence, setSequence] = useState("");
  const [matches, setMatches] = useState<GenomicMatch[] | null>(null);
  const [loading, setLoading] = useState(false);

  const handleIdentify = () => {
    setLoading(true);
    // Simulation délai calcul
    setTimeout(() => {
        const results = identifyGenomic(sequence);
        setMatches(results);
        setLoading(false);
    }, 600);
  };

  const loadExample = () => {
      setSequence(">Seq_Unknown_01\nAGAGTTTGATCATGGCTCAGATTGAACGCTGGCGGCAGGCCTAACACATGCAAGTCGAACGGTAACAGGA");
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 animate-fade-in">
      {/* Input Section */}
      <div className="space-y-6">
        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
            <h2 className="text-xl font-bold text-slate-800 mb-4 flex items-center gap-2">
                <Dna className="w-6 h-6 text-purple-600" />
                Séquençage 16S rRNA
            </h2>
            <p className="text-sm text-slate-600 mb-4">
                Collez votre séquence FASTA brute pour effectuer un alignement local contre notre base de référence (K-mer Jaccard Index).
            </p>
            
            <textarea
                value={sequence}
                onChange={(e) => setSequence(e.target.value)}
                placeholder=">Header&#10;ATGC..."
                className="w-full h-64 p-4 font-mono text-sm bg-slate-50 border border-slate-300 rounded-lg focus:ring-2 focus:ring-purple-500 outline-none resize-none"
            />
            
            <div className="flex gap-3 mt-4">
                <button
                    onClick={handleIdentify}
                    disabled={loading || sequence.length < 10}
                    className={`flex-1 py-3 px-4 rounded-lg text-white font-semibold shadow-md transition-all flex items-center justify-center gap-2
                    ${(loading || sequence.length < 10) ? 'bg-slate-400 cursor-not-allowed' : 'bg-purple-600 hover:bg-purple-700'}`}
                >
                    {loading ? "Alignement en cours..." : <><Search className="w-4 h-4" /> Identifier</>}
                </button>
                <button
                    onClick={loadExample}
                    className="px-4 py-3 bg-white border border-slate-300 text-slate-700 rounded-lg font-medium hover:bg-slate-50 transition-colors"
                >
                    Exemple
                </button>
            </div>
        </div>
      </div>

      {/* Results Section */}
      <div className="space-y-6">
        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm h-full min-h-[400px]">
            <h3 className="text-lg font-bold text-slate-800 mb-4 border-b border-slate-100 pb-2">Résultats d'Alignement</h3>
            
            {!matches && !loading && (
                <div className="h-64 flex flex-col items-center justify-center text-slate-400">
                    <FileText className="w-12 h-12 mb-3 opacity-50" />
                    <p>Aucune analyse effectuée.</p>
                </div>
            )}

            {loading && (
                <div className="h-64 flex flex-col items-center justify-center text-purple-600">
                    <div className="animate-spin rounded-full h-10 w-10 border-t-2 border-b-2 border-purple-600 mb-4"></div>
                    <p>Recherche d'homologie...</p>
                </div>
            )}

            {matches && matches.length === 0 && (
                <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 flex items-start gap-3 text-yellow-800">
                    <AlertTriangle className="w-5 h-5 flex-shrink-0 mt-0.5" />
                    <div>
                        <h4 className="font-semibold">Aucune correspondance trouvée</h4>
                        <p className="text-sm">La séquence fournie ne correspond à aucun organisme de notre base de données 16S avec une confiance suffisante.</p>
                    </div>
                </div>
            )}

            {matches && matches.length > 0 && (
                <div className="space-y-4">
                    {matches.map((match, idx) => (
                        <div key={idx} className="border border-slate-200 rounded-lg p-4 hover:border-purple-300 transition-colors bg-slate-50">
                            <div className="flex justify-between items-start mb-2">
                                <h4 className="text-lg font-bold text-slate-800">{match.organism}</h4>
                                <span className={`px-3 py-1 rounded-full text-xs font-bold ${
                                    match.similarity > 90 ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'
                                }`}>
                                    {match.similarity}% ID
                                </span>
                            </div>
                            <p className="text-sm text-slate-600 mb-3">{match.description}</p>
                            <div className="w-full bg-slate-200 rounded-full h-2">
                                <div 
                                    className="bg-purple-600 h-2 rounded-full transition-all duration-1000" 
                                    style={{ width: `${match.similarity}%` }}
                                ></div>
                            </div>
                        </div>
                    ))}
                </div>
            )}
        </div>
      </div>
    </div>
  );
};